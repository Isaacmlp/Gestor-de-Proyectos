package view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ViewAdminMenu extends JFrame {
    Font font = new Font("Dialog",Font.BOLD,18);
    DefaultTableModel tableModel;
    JTable table;
    JScrollPane scrollPane;
    JButton add,edit,delete,exit;

    public ViewAdminMenu(){
        getContentPane().setLayout(null);
        JLabel label = new JLabel("Register Patients");
        label.setFont(font);

        String[] columnTitles = {"ID","First Name","Last Name","Born","Telephone","Address"};
        Object[][] data ={
                {1,"Javier", "Perez", "06-02-2002","04128585280","Urb Lomas del Este"},
                {2,"Jane", "Bravo", "26-09-2002","04120439162","Urb Lomas del Este"}
        };

        tableModel = new DefaultTableModel(data,columnTitles);
        JTable table = new JTable(tableModel);
        table.setPreferredScrollableViewportSize(new Dimension(250, 100));
        scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50,50,600,216);
        label.setBounds(300,5,250,50);

        JButton add = new JButton("Add");
        add.setBounds(660,50,100,50);

        JButton edit = new JButton("Edit");
        edit.setBounds(660,105,100,50);

        JButton delete = new JButton("Delete");
        delete.setBounds(660,160,100,50);

        JButton exit = new JButton("Exit");
        exit.setBounds(660,215,100,50);

        getContentPane().add(label);
        getContentPane().add(scrollPane);
        getContentPane().add(add);
        getContentPane().add(edit);
        getContentPane().add(delete);
        getContentPane().add(exit);

    }

}
