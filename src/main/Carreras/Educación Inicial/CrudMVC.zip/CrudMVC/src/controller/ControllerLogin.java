package controller;

import model.ModelUser;
import view.ViewAdminMenu;
import view.ViewLogin;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.Thread;

public class ControllerLogin implements ActionListener {

    ViewLogin viewLogin = new ViewLogin();
    ModelUser modelUser = new ModelUser();

    public ControllerLogin(ViewLogin viewLogin, ModelUser modelUser){
        this.viewLogin = viewLogin;
        this.modelUser = modelUser;
        this.viewLogin.getSubmitBtn().addActionListener(this);
    }

    public void startLogin(){
        viewLogin.setSize(300,400);
        viewLogin.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        viewLogin.setLocationRelativeTo(null);
        viewLogin.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == viewLogin.getSubmitBtn()) {
            String username = viewLogin.getUsernameTxt().getText();
            String password = viewLogin.getPasswordTxt().getText();
            boolean user_check = modelUser.verifyUser(username, password);

            if (user_check) {
                viewLogin.successMessage("Login Success");

                // Pause for 1 second (adjust as needed)
                try {
                    Thread.sleep(10000);
                } catch (InterruptedException ex) {
                    ex.printStackTrace(); // Handle interruption (optional)
                }

                ViewAdminMenu adminMenu = new ViewAdminMenu();
                viewLogin.dispose();
                viewLogin.exitMessages();
                viewLogin.getUsernameTxt().setText("");
                viewLogin.getPasswordTxt().setText("");
            } else {
                viewLogin.errorMessage("Error Login");
                viewLogin.exitMessages();
                viewLogin.getUsernameTxt().setText("");
                viewLogin.getPasswordTxt().setText("");
            }
        }
    }

}
