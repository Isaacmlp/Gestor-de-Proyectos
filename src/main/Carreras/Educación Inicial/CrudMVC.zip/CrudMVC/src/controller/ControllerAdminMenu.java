package controller;

import model.ModelPatients;
import view.ViewAdminMenu;

import javax.swing.*;

public class ControllerAdminMenu {
    ModelPatients modelPatients = new ModelPatients();
    ViewAdminMenu viewAdminMenu = new ViewAdminMenu();


    public ControllerAdminMenu(ViewAdminMenu viewAdminMenu, ModelPatients modelPatients){
        this.viewAdminMenu = viewAdminMenu;
        this.modelPatients = modelPatients;
    }

    public void startScreen(){
        viewAdminMenu.setSize(800,350);
        viewAdminMenu.setLocationRelativeTo(null);
        viewAdminMenu.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        viewAdminMenu.setVisible(true);

    }

}
