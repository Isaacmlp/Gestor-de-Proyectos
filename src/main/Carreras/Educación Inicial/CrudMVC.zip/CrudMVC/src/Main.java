import controller.ControllerAdminMenu;
import controller.ControllerLogin;

import model.ModelPatients;
import model.ModelUser;
import view.ViewAdminMenu;
import view.ViewLogin;

public class Main {

    public static void main(String[] args) {
        /*
        ViewLogin viewLogin = new ViewLogin();
        ModelUser modelUser = new ModelUser();

        ControllerLogin controllerLogin = new ControllerLogin(viewLogin,modelUser);
        controllerLogin.startLogin();
        */

        ViewAdminMenu viewAdminMenu = new ViewAdminMenu();
        ModelPatients modelPatients = new ModelPatients();
        ControllerAdminMenu controllerAdminMenu = new ControllerAdminMenu(viewAdminMenu,modelPatients);
        controllerAdminMenu.startScreen();

        }

    }