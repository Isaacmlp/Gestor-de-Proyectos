package model;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

public class ModelConexionBD {
    private String driver = "com.mysql.cj.jdbc.Driver"; //Library driver
    private String database = "crud_mvc"; // Name Database
    private String host = "localhost"; // Localhost
    private String port = "3306"; // Port
    private String username = "jadape"; //Username the DB
    private String password = "jadape.21"; // Password the user
    private String url = "jdbc:mysql://" + host + ":" + port + "/" + database;

    public Connection connectDB(){
        Connection conn = null;
        try{
            Class.forName(driver);
            conn = DriverManager.getConnection(url,username,password);
        }catch(ClassNotFoundException | SQLException e){
            e.printStackTrace();
        }
        return conn;
    }

}
