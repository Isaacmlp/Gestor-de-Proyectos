package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ModelUser {
    private String username;
    private String password;
    private String typeUser;
    private ModelConexionBD model = new ModelConexionBD();

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTypeUser() {
        return typeUser;
    }

    public void setTypeUser(String typeUser) {
        this.typeUser = typeUser;
    }

    public boolean verifyUser(String username,String password){
        try {
            Connection connect = model.connectDB();
            String sql = "SELECT COUNT(*) FROM User WHERE username = ? AND password = ?";
            PreparedStatement statament = connect.prepareStatement(sql);
            statament.setString(1,username);
            statament.setString(2,password);
            ResultSet result = statament.executeQuery();

            if (result.next()) {
                int count = result.getInt(1);
                return count > 0;
            } else {
                return false;
            }
        }catch (Exception e){
            e.printStackTrace();
            return  false;
        }
    }
}
